function Introduction2(props) {
  return <h2>제 나이는 {props.age}이고, {props.major}을(를) 전공했습니다.</h2>
}

export default Introduction2