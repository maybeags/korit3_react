function Introduction3({futureJob, certificate}) {
  return (
    <>
      <p>
        제 현재 목표는 {futureJob}이며, 이를 위해서 {certificate}를 취득했습니다.
      </p>
      
    </>
  )
}

export default Introduction3