import Introduction1 from "./Introduction1"
import Introduction2 from "./Introduction2"
import Introduction3 from "./Introduction3"

function App() {
// 지시 사항
// 2는 Props 이용
// 3은 객체 구조 분해를 사용할 것

  return (
    <>
      <Introduction1 />
      <Introduction2 age='38' major='영어교육과' />
      <Introduction3 futureJob = 'Full Stack 개발자' certificate='정보처리기사, SQLD' />
    </>
    
  )
}

export default App
