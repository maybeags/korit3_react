
function Introduction1() {
  return(
    <h1>안녕하세요, 제 이름은 김일입니다.</h1>
  )
}

export default Introduction1